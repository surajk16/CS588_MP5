import open3d as o3d
import numpy as np

with open("./points.csv") as f:
    csv_lines = f.readlines()

# Remove parentheses from each line of the CSV file
cleaned_lines = [line.strip().replace("(", "").replace(")", "") for line in csv_lines]

# Load cleaned data into a NumPy array
data = np.loadtxt(cleaned_lines, delimiter=",")
print(data[:, :3])
# Convert numpy array to Open3D point cloud
pcd = o3d.geometry.PointCloud()
pcd.points = o3d.utility.Vector3dVector(data[:, :3])

# Visualize the point cloud
o3d.visualization.draw_geometries([pcd])

# Voxel downsample the point cloud
voxel_down_pcd = pcd.voxel_down_sample(voxel_size=0.05)

# Remove points outside of a certain range
pass_pcd = voxel_down_pcd.crop(o3d.geometry.AxisAlignedBoundingBox(min_bound=(-20, -20, -1), max_bound=(20, 20, 1)))

# Plane segmentation
plane_model, inliers = pass_pcd.segment_plane(distance_threshold=0.1, ransac_n=3, num_iterations=100)
inlier_cloud = pass_pcd.select_by_index(inliers)
outlier_cloud = pass_pcd.select_by_index(inliers, invert=True)

# Clustering
with o3d.utility.VerbosityContextManager(o3d.utility.VerbosityLevel.Debug) as cm:
    labels = np.array(outlier_cloud.cluster_dbscan(eps=0.5, min_points=10, print_progress=True))
max_label = labels.max()

# Compute centroids of the two clusters
centers = []
for i in range(max_label + 1):
    indices = np.where(labels == i)[0]
    pcd_cluster = outlier_cloud.select_by_index(indices)
    center = np.mean(np.asarray(pcd_cluster.points), axis=0)
    centers.append(center)
    if len(centers) >= 2:
        break

print(f"Box 1 center: {centers[0]}")
print(f"Box 2 center: {centers[1]}")
