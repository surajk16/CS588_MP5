import numpy as np
import pandas as pd
import math

def calculate_midpoint(p1, p2):
    return (p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2

def calculate_distance(p1, p2):
    return np.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)

def generate_and_save_path(start, box1, box2, n_points=1000, file_name="path.csv"):
    def generate_path(start, mid, circle_center, radius, n_points):
        path = []
        angle_increment = 2 * np.pi / (n_points - n_points // 2 - 1)
	# Linear interpolation from start to midpoint
        t_values = np.linspace(0, 1, n_points // 2)
        interp_points = [(1 - t) * np.array(start) + t * np.array(mid) for t in t_values]
        path.extend(interp_points)

        # Generate points along the circle
        for i in range(n_points // 2 - 1):
            angle = angle_increment * i
            x = circle_center[0] - radius * np.sin(angle)
            y = circle_center[1] - radius * np.cos(angle)
            path.append((x, y))
	
        # Calculate headings
        path_with_headings = []
        for i in range(len(path) - 1):
            dx = path[i + 1][0] - path[i][0]
            dy = path[i + 1][1] - path[i][1]
            heading = 180-math.degrees(math.atan2(dy, dx))
            path_with_headings.append((*path[i], heading))
        path_with_headings.append((*path[-1], heading))

        return path_with_headings

    # Calculate the midpoint between the two box locations
    midpoint = calculate_midpoint(box1, box2)
    print(midpoint)
    # Choose a box location as the center of the circle and calculate the radius
    circle_center = box1
    radius = calculate_distance(midpoint, circle_center)
    print(radius)
    # Generate the path with the specified number of points
    path = generate_path(start, midpoint, circle_center, radius, n_points)

    # Save the path as a CSV file
    path_df = pd.DataFrame(path, columns=["x", "y", "heading"])
    path_df.to_csv(file_name, index=False)
# Your current position, and box locations
start = (4.031, -9.641)
box1 = (15.085, -6.514)
box2 = (15.429, -13.901)

# Call the function with your current location and box locations
generate_and_save_path(start, box1, box2)
