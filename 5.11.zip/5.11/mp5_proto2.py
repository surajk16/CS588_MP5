#!/usr/bin/env python3

# ==============================================================================
# File name          : mp5.py                                                                 
# Description        : CS588 Exercise 5: Rizz                                                                                 
# Usage              : python3 mp3.py                                                                                               # reference: https://github.com/hangcui1201/POLARIS_GEM_e2_Real/blob/main/vehicle_drivers/gem_pacmod_control/scripts/gem_pacmod_control.py                         

# ==============================================================================
from __future__ import print_function

# Python Headers
import math
import os
import numpy as np

# ROS Headers
import rospy

# GEM PACMod Headers
from std_msgs.msg import Header, String, Bool, Float32, Float64
from pacmod_msgs.msg import PacmodCmd, PositionWithSpeed, VehicleSpeedRpt
from ackermann_msgs.msg import AckermannDrive
import open3d as o3d
# lidar
# from sensor_msgs.msg import LaserScan 
# scan only scan a horizon plane at a fixed height, so we switch to use point cloud
from sensor_msgs.msg import PointCloud2
import sensor_msgs.point_cloud2 as pc2

# pid
from simple_pid import PID

MAX_SPEED_LIMIT = 0.4
MIN_SPEED_LIMIT = 0.1 # Change: need to experiment out 

DEBUG = True


class Node():

    def __init__(self):

        # 10Hz for rate.sleep ~ 0.1s/
        self.rate = rospy.Rate(10)

        self.target_distance = 5  # fixed distance to the person 
        self.measure_distance = 5  # initial distance to the person
        self.steering_angle = 0  # angle of the person
        self.closest_point = None  # the closest point
        self.accl = 0.0  # parameter of the accelerator
        self.direction = 0 # for complex car control, 0 for stop, -1 for backward, 1 for forward

        # LIDAR
        # self.scan_sub = rospy.Subscriber('/lidar1/scan', LaserScan, self.scanCallback)
        self.scan_sub = rospy.Subscriber('/lidar1/velodyne_points', PointCloud2, self.scanCallback)

        # pid
        # TODO: the parameters may need to be adjusted 
        # Change: [sample_time:Update every sample_time seconds] used to be 1s, but since the rate of sleep is 0.1s, then changed to 0.1
        self.PID = PID(0.5, 0.06, 0.0, setpoint=self.target_distance, sample_time=0.1, output_limits=(-5, 5))

        # Setup 
        self.stanley_sub = rospy.Subscriber('/gem/stanley_gnss_cmd', AckermannDrive, self.stanley_gnss_callback)
        self.speed_sub = rospy.Subscriber('/pacmod/as_tx/vehicle_speed', Float64, self.speed_callback)

        self.ackermann_msg_gnss = AckermannDrive()
        self.ackermann_msg_gnss.steering_angle_velocity = 0.0
        self.ackermann_msg_gnss.acceleration = 0.0
        self.ackermann_msg_gnss.jerk = 0.0
        self.ackermann_msg_gnss.speed = 0.0
        self.ackermann_msg_gnss.steering_angle = 0.0

        # GEM
        self.gem_enable = False
        self.pacmod_enable = True

        # GEM vehicle gear control, neutral, forward and reverse, publish once
        self.gear_pub = rospy.Publisher('/pacmod/as_rx/shift_cmd', PacmodCmd, queue_size=1)
        self.gear_cmd = PacmodCmd()
        self.gear_cmd.ui16_cmd = 2  # SHIFT_NEUTRAL

        # GEM vehilce brake control
        self.brake_pub = rospy.Publisher('/pacmod/as_rx/brake_cmd', PacmodCmd, queue_size=1)
        self.brake_cmd = PacmodCmd()
        self.brake_cmd.enable = False
        self.brake_cmd.clear = True
        self.brake_cmd.ignore = True

        # GEM vechile forward motion control
        self.accel_pub = rospy.Publisher('/pacmod/as_rx/accel_cmd', PacmodCmd, queue_size=1)
        self.accel_cmd = PacmodCmd()
        self.accel_cmd.enable = False
        self.accel_cmd.clear = True
        self.accel_cmd.ignore = True
        
        self.gnss_sub   = rospy.Subscriber("/novatel/inspva", Inspva, self.inspva_callback)
        self.lat        = 0.0
        self.lon        = 0.0
        self.heading    = 0.0
        # GEM vechile steering wheel control
        self.steer_pub = rospy.Publisher('/pacmod/as_rx/steer_cmd', PositionWithSpeed, queue_size=1)
        self.steer_cmd = PositionWithSpeed()
        self.steer_cmd.angular_position = 0.0  # radians, -: clockwise, +: counter-clockwise
        self.steer_cmd.angular_velocity_limit = 2.0  # radians/second
        self.lat        = 0.0
        self.lon        = 0.0
        self.olat       = 40.0928563
        self.olon       = -88.2359994
    def speed_callback(self, speed_msg):
        self.speed = speed_msg.data
    def inspva_callback(self, inspva_msg):
        self.lat     = inspva_msg.latitude  # latitude
        self.lon     = inspva_msg.longitude # longitude
        self.heading = inspva_msg.azimuth   # heading in degrees
    def stanley_gnss_callback(self, msg):
        self.ackermann_msg_gnss.acceleration = round(msg.acceleration, 2)
        self.ackermann_msg_gnss.steering_angle = round(msg.steering_angle, 2)
        self.ackermann_msg_gnss.speed = round(msg.speed, 2)

        print("self.ackermann_msg_gnss.speed", self.ackermann_msg_gnss.speed)
        print("self.ackermann_msg_gnss.steering_angle", self.ackermann_msg_gnss.steering_angle)
        print("self.ackermann_msg_gnss.acceleration", self.ackermann_msg_gnss.acceleration)
    def wps_to_local_xy(self, lon_wp, lat_wp):
            # convert GNSS waypoints into local fixed frame reprented in x and y
            lon_wp_x, lat_wp_y = axy.ll2xy(lat_wp, lon_wp, self.olat, self.olon)
            return lon_wp_x, lat_wp_y  
    def get_gem_state(self):

        # vehicle gnss heading (yaw) in degrees
        # vehicle x, y position in fixed local frame, in meters
        # reference point is located at the center of GNSS antennas
        local_x_curr, local_y_curr = self.wps_to_local_xy(self.lon, self.lat)

        # heading to yaw (degrees to radians)
        # heading is calculated from two GNSS antennas
        curr_yaw = self.heading_to_yaw(self.heading) 

        # reference point is located at the center of rear axle
        curr_x = local_x_curr - self.offset * np.cos(curr_yaw)
        curr_y = local_y_curr - self.offset * np.sin(curr_yaw)

        return round(curr_x, 3), round(curr_y, 3), round(curr_yaw, 4)
    def scanCallback(self, msg):
        pc = pc2.read_points(msg, skip_nans=True, field_names=("x", "y", "z"))
        min_xyz = None
        min_phi = None  # angle between the point and the z-plane
        min_dist = math.inf
        data=[]
        for i in pc:
            x, y, z = i
            data.append([x,y,z])
        data=np.array(data)
        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(data[:, :3])

        # Visualize the point cloud
        #o3d.visualization.draw_geometries([pcd])

        # Voxel downsample the point cloud
        voxel_down_pcd = pcd.voxel_down_sample(voxel_size=0.05)

        # Remove points outside of a certain range
        pass_pcd = voxel_down_pcd.crop(o3d.geometry.AxisAlignedBoundingBox(min_bound=(-20, -5, -1), max_bound=(20, 5, 1)))

        # Plane segmentation
        plane_model, inliers = pass_pcd.segment_plane(distance_threshold=0.1, ransac_n=3, num_iterations=100)
        inlier_cloud = pass_pcd.select_by_index(inliers)
        outlier_cloud = pass_pcd.select_by_index(inliers, invert=True)

        # Clustering
        with o3d.utility.VerbosityContextManager(o3d.utility.VerbosityLevel.Debug) as cm:
            labels = np.array(outlier_cloud.cluster_dbscan(eps=0.5, min_points=10, print_progress=True))
        max_label = labels.max()

        # Compute centroids of the two clusters
        centers = []
        for i in range(max_label + 1):
            indices = np.where(labels == i)[0]
            pcd_cluster = outlier_cloud.select_by_index(indices)
            center = np.mean(np.asarray(pcd_cluster.points), axis=0)
            centers.append(center)
            if len(centers) >= 2:
                break
        curr_x, curr_y, curr_yaw = self.get_gem_state()
        if self.heading != 0:
            print(str(curr_x)+'   '+str(curr_y))
        print(f"Box 1 center: {centers[0]}")
        print(f"Box 2 center: {centers[1]}")


    def run(self):

        while not rospy.is_shutdown():
            pass

if __name__ == '__main__':
    rospy.init_node('person_follower', anonymous=True)
    node = Node()
    node.run()
