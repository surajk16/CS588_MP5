import pandas as pd
import matplotlib.pyplot as plt

def plot_path_from_csv(csv_file):
    # Read CSV file
    path_df = pd.read_csv(csv_file)

    # Plot the path
    plt.figure()
    plt.plot(path_df['x'], path_df['y'], marker='o', markersize=2, linestyle='-', linewidth=0.5)
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.title('Generated Path')
    plt.grid()

    # Show the plot
    plt.show()

# Call the function with the name of the CSV file
csv_file = "path.csv"
plot_path_from_csv(csv_file)