# MP5

> CS 588 Vehicle Exercise 5: Using LIDAR to position the vehicle


# TODO:
1. test:
```python
            # version 1
            alpha_v1 = self.heading_to_yaw(self.path_points_heading[self.goal]) - curr_yaw

            # version 2
            v1 = [self.path_points_x[self.goal]-curr_x , self.path_points_y[self.goal]-curr_y]
            v2 = [np.cos(curr_yaw), np.sin(curr_yaw)]
            alpha_v2 = self.find_angle(v1,v2)

            # version 3
            alpha_v3 = math.atan(v1[1]/v1[0]) - curr_yaw 
```            
