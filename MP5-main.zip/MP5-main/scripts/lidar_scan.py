#!/usr/bin/env python3

#================================================================
# File name: lidar_scan.py                                                                  
# Description:                     
# 1. Use Lidar to get the point cloud 
# 2. Use the point cloud to identify two blocks
# 3. Get the centers of the two blocks  
# Author: Group 3                                                                    
# Version: 0.1                                                                    
# Usage: rosrun gem_gnss lidar_scan.py                                                                      
# Python version: 3.8                                                             
#================================================================
from __future__ import print_function

# Python Headers
import os 
import csv
import math
import numpy as np
# from numpy import linalg as la
# import scipy.signal as signal
from datetime import datetime
import configparser

# ROS Headers
import alvinxy.alvinxy as axy # Import AlvinXY transformation module
import rospy

# GEM Sensor Headers
from std_msgs.msg import String, Bool, Float32, Float64
from novatel_gps_msgs.msg import NovatelPosition, NovatelXYZ, Inspva

# GEM PACMod Headers
from std_msgs.msg import Header, String, Bool, Float32, Float64
from pacmod_msgs.msg import PacmodCmd, PositionWithSpeed, VehicleSpeedRpt
from ackermann_msgs.msg import AckermannDrive

# lidar
from sensor_msgs.msg import PointCloud2
import sensor_msgs.point_cloud2 as pc2

# pcl
# import pcl
import matplotlib.pyplot as plt

from waypoints import WaypointGenerator

MIN_THREHOLD = 2
MAX_THREHOLD = 13

class BlockScanner():

    def __init__(self):
         # 10Hz for rate.sleep ~ 0.1s/
        self.rate = rospy.Rate(1)

        # LIDAR
        self.scan_sub = rospy.Subscriber('/lidar1/velodyne_points', PointCloud2, self.scanCallback)
        self.pc_list = []
        self.pointCloud = None


        # GPS 
        self.lat      = 0
        self.lon      = 0
        self.heading  = 0
        self.yaw = 0
        self.gnss_sub   = rospy.Subscriber("/novatel/inspva", Inspva, self.inspva_callback)
        self.offset     = 0.46
        self.olat       = 40.0928563
        self.olon       = -88.2359994

    def heading_to_yaw(self, heading_curr):
        # 0   <= heading < 90  --- 90 to 0     (pi/2 to 0)
        # 90  <= heading < 180 --- 0 to -90    (0 to -pi/2)
        # 180 <= heading < 270 --- -90 to -180 (-pi/2 to -pi)
        # 270 <= heading < 360 --- 180 to 90   (pi to pi/2)
        if (heading_curr >= 0 and heading_curr < 90):
            yaw_curr = np.radians(90 - heading_curr)
        elif(heading_curr >= 90 and heading_curr < 180):
            yaw_curr = np.radians(90 - heading_curr)
        elif(heading_curr >= 180 and heading_curr < 270):
            yaw_curr = np.radians(90 - heading_curr)
        else:
            yaw_curr = np.radians(450 - heading_curr)
        return yaw_curr

    def wps_to_local_xy(self, lon_wp, lat_wp):
        # convert GNSS waypoints into local fixed frame reprented in x and y
        lon_wp_x, lat_wp_y = axy.ll2xy(lat_wp, lon_wp, self.olat, self.olon)
        return lon_wp_x, lat_wp_y   
    
    def inspva_callback(self, inspva_msg):
        local_x_curr, local_y_curr = self.wps_to_local_xy(inspva_msg.longitude, inspva_msg.latitude)
        curr_yaw = self.heading_to_yaw(inspva_msg.azimuth) 

        # reference point is located at the center of rear axle
        # reference point is located at the center of rear axle
        curr_x = local_x_curr - self.offset * np.cos(curr_yaw)
        curr_y = local_y_curr - self.offset * np.sin(curr_yaw)

        # round(curr_x, 3), round(curr_y, 3), round(curr_yaw, 4)
        self.lon     = round(curr_x, 3)
        self.lat     = round(curr_y, 3)
        self.heading     = inspva_msg.azimuth
        self.yaw = curr_yaw

    def scanCallback(self, msg):
        pc = pc2.read_points(msg, skip_nans=True, field_names=("x", "y", "z"))
        pc_list = []
        for p in pc:
            x, y, z = p
            if MIN_THREHOLD < np.sqrt(x**2 + y**2 + z**2) and abs(y) < MAX_THREHOLD and 0 < x < MAX_THREHOLD:
                pc_list.append([p[0], p[1], p[2]])
        # p = pcl.PointCloud()
        # p.from_list(pc_list)
        self.pc_list = pc_list
        # self.pointCloud = p

    def saveAsFile(self, filename, pc_list):
        with open(filename, 'w') as f:
            for x, y, z in pc_list:
                f.write("{},{},{}\n".format(x,y,z))
          

    def segment(self):
        # make a segmenter
        p = self.pointCloud
        pc_list = self.pc_list

        self.saveAsFile("point_cloud.txt", pc_list)

        seg = p.make_segmenter()
        seg.set_model_type(pcl.SACMODEL_PLANE)  # equation form: ax + by + cz + d = 0
        seg.set_method_type(pcl.SAC_RANSAC)
        indices, model = seg.segment()
        # Create a Euclidean Cluster Extraction object
        ec = p.make_EuclideanClusterExtraction()
        ec.set_ClusterTolerance(0.01) # set the cluster tolerance to 1 cm
        ec.set_MinClusterSize(100) # set the minimum cluster size to 100 points
        ec.set_MaxClusterSize(10000) # set the maximum cluster size to 10,000 points
        ec.set_SearchMethod(pcl.KdTree()) # set the search method to KdTree
        # Extract the clusters
        clusters = ec.Extract()
        # Find the centers of the two boxes
        centers = []
        for cluster in clusters:
            cloud_cluster = pcl.PointCloud()
            cloud_cluster.from_list([pc_list[i] for i in cluster.indices])
            center = cloud_cluster.get_centroid()
            centers.append(center)
        print("centers: ", centers)


    def density_method(self):
        # Parse the data and filter out points too far
        data = self.pc_list
        self.saveAsFile("point_cloud.txt", data)
        # threshold = 6
        points = np.array(data)
        # filtered_points = points[np.linalg.norm(points, axis=1) <= threshold]

        # Project points to the XY plane
        # projected_points = points[:, :2]
        projected_points = points

        # Split the plane into blocks
        num_blocks = (12, 12)  # 5x5 blocks
        block_ranges = [
            (np.min(projected_points[:, 0]), np.max(projected_points[:, 0])),
            (np.min(projected_points[:, 1]), np.max(projected_points[:, 1]))
        ]
        block_size = [
            (block_ranges[0][1] - block_ranges[0][0]) / num_blocks[0],
            (block_ranges[1][1] - block_ranges[1][0]) / num_blocks[1]
        ]

        # Calculate the amount of points in each block
        block_counts = np.zeros(num_blocks, dtype=int)
        for point in projected_points:
            if point[2] > 0 or point[2] < -1.4:
                continue
            block_idx = (
                int((point[0] - block_ranges[0][0]) // block_size[0]),
                int((point[1] - block_ranges[1][0]) // block_size[1])
            )
            if block_idx[0] >= num_blocks[0] or block_idx[1] >= num_blocks[1]:
                continue
            block_counts[block_idx] += 1

        # Find the central point of the two blocks with most points
        two_highest_blocks = np.argpartition(block_counts.flatten(), -2)[-2:]
        block_centers = []
        for block_idx in two_highest_blocks:
            x_idx, y_idx = np.unravel_index(block_idx, block_counts.shape)
            x_center = block_ranges[0][0] + (x_idx + 0.5) * block_size[0]
            y_center = block_ranges[1][0] + (y_idx + 0.5) * block_size[1]
            block_centers.append((x_center, y_center))

        print(block_centers)


        # Visualize the projected points and block centers
        plt.scatter(projected_points[:, 0], projected_points[:, 1], label='Projected Points')
        plt.scatter(*zip(*block_centers), color='red', marker='x', s=100, label='Block Centers')

        # Set up the gridlines for the blocks
        for i in range(1, num_blocks[0]):
            plt.axvline(block_ranges[0][0] + i * block_size[0], color='grey', linestyle='--', linewidth=0.5)
        for i in range(1, num_blocks[1]):
            plt.axhline(block_ranges[1][0] + i * block_size[1], color='grey', linestyle='--', linewidth=0.5)

        plt.legend()
        plt.xlabel('X')
        plt.ylabel('Y')
        plt.title('Projected Points and Block Centers')
        plt.show()
        return block_centers

    def get_destination_xy(self, center1, center2):
        return (center1[0]+center2[0])/2, (center1[1]+center2[1])/2

    def run(self):
        while not rospy.is_shutdown():
            if self.pc_list and self.lat:
                # log some info
                dirname = os.path.dirname(__file__)
                now = datetime.now()
                hour = now.hour
                minute = now.minute
                time_str = f"{hour:02d}{minute:02d}"
                
                center1, center2 = self.density_method()
                wpg = WaypointGenerator(center1, center2)
                wpg.generateWaypoints()
                # wpg.readFromCSV("/home/gem/demo_ws/src/MP5-main/waypoints/relative_waypoints.csv")
                wpg.visualize()
                wpg.saveAsCSV(os.path.join(dirname, f"../waypoints/relative_waypoints_{time_str}.csv"))

                # print(self.lat, self.lon, self.heading)
                # with open(os.path.join(dirname, f'../log/latlon_{time_str}.txt'), 'w') as f:
                #     f.write(f'{self.lat},{self.lon},{self.heading}\n')
                #     f.write(f'{center1},{center2}')
                wpg.transform_points(self.lon, self.lat, self.heading)

                # wpg.visualize()
                abs_filename = os.path.join(dirname, f"../waypoints/absolute_waypoints_{time_str}.csv")
                wpg.saveAsCSV(abs_filename)
                print("=== Successfully generated absolute waypoints and save as csv file ===")
               
                abs_center1, abs_center2 = wpg.get_centers()
                # dest_x, dest_y = self.get_destination_xy(abs_center1, abs_center2)

                # create a configuration object
                config = configparser.ConfigParser()
                config["latlon"] = {'lat': self.lat, 'lon': self.lon, 'heading': self.heading}
                config["relative_center"] = {'center1': center1, 'center2': center2}
                config["absolute_center"] = {'center1': abs_center1, 'center2': abs_center2}
                config["relative_filename"] = {'filename': f"../waypoints/relative_waypoints_{time_str}.csv"}
                config["absolute_filename"] = {'filename': f"../waypoints/absolute_waypoints_{time_str}.csv"}
                config_filepath = os.path.join(dirname, f'../log/log_{time_str}.ini')
                # write the configuration to a file
                with open(config_filepath, 'w') as configfile:
                    config.write(configfile)
                
                return abs_filename, abs_center1, abs_center2
            self.rate.sleep()
            
def block_scan():

    pp = BlockScanner()

    try:
        abs_filename = pp.run()
        return abs_filename
    except rospy.ROSInterruptException:
        pass


if __name__ == "__main__":
    block_scan()