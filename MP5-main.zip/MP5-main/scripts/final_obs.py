#!/usr/bin/env python3

#================================================================
# File name: gem_gnss_pp_tracker_pid.py                                                                  
# Description: gnss waypoints tracker using pid and pure pursuit                                                                
# Author: Hang Cui
# Email: hangcui3@illinois.edu                                                                     
# Date created: 08/02/2021                                                                
# Date last modified: 08/13/2021                                                          
# Version: 0.1                                                                    
# Usage: rosrun gem_gnss gem_gnss_pp_tracker.py                                                                      
# Python version: 3.8                                                             
#================================================================

from __future__ import print_function

# Python Headers
import os 
import csv
import math
import numpy as np
from numpy import linalg as la
import scipy.signal as signal

# ROS Headers
import alvinxy.alvinxy as axy # Import AlvinXY transformation module
import rospy

# GEM Sensor Headers
from std_msgs.msg import String, Bool, Float32, Float64
from novatel_gps_msgs.msg import NovatelPosition, NovatelXYZ, Inspva

# GEM PACMod Headers
from pacmod_msgs.msg import PositionWithSpeed, PacmodCmd

import matplotlib.pyplot as plt
import pandas as pd

# destination waypoint
from dest_waypoints import destinationWayPoint
# destinationWayPoint = (40.682, -9.637, 102.82558429946185)
# lidar
from sensor_msgs.msg import PointCloud2
import sensor_msgs.point_cloud2 as pc2

class PID(object):

    def __init__(self, kp, ki, kd, wg=None):

        self.iterm  = 0
        self.last_t = None
        self.last_e = 0
        self.kp     = kp
        self.ki     = ki
        self.kd     = kd
        self.wg     = wg
        self.derror = 0

    def reset(self):
        self.iterm  = 0
        self.last_e = 0
        self.last_t = None

    def get_control(self, t, e, fwd=0):

        if self.last_t is None:
            self.last_t = t
            de = 0
        else:
            de = (e - self.last_e) / (t - self.last_t)

        if abs(e - self.last_e) > 0.5:
            de = 0

        self.iterm += e * (t - self.last_t)

        # take care of integral winding-up
        if self.wg is not None:
            if self.iterm > self.wg:
                self.iterm = self.wg
            elif self.iterm < -self.wg:
                self.iterm = -self.wg

        self.last_e = e
        self.last_t = t
        self.derror = de

        return fwd + self.kp * e + self.ki * self.iterm + self.kd * de


class OnlineFilter(object):

    def __init__(self, cutoff, fs, order):
        
        nyq = 0.5 * fs
        normal_cutoff = cutoff / nyq

        # Get the filter coefficients 
        self.b, self.a = signal.butter(order, normal_cutoff, btype='low', analog=False)

        # Initialize
        self.z = signal.lfilter_zi(self.b, self.a)
    
    def get_data(self, data):
        filted, self.z = signal.lfilter(self.b, self.a, [data], zi=self.z)
        return filted


class PurePursuit(object):
    
    def __init__(self):

        
        self.rate       = rospy.Rate(20)

        self.look_ahead = 100
        self.wheelbase  = 1.75 # meters
        self.offset     = 0.46 # meters

        self.measure_distance = 5  # initial distance to the person
        self.delta_angle = 0  # angle of the obs to car
        self.closest_point = None  # the closest point

        self.gnss_sub   = rospy.Subscriber("/novatel/inspva", Inspva, self.inspva_callback)
        self.lat        = 0.0
        self.lon        = 0.0
        self.heading    = 0.0

        self.enable_sub = rospy.Subscriber("/pacmod/as_tx/enable", Bool, self.enable_callback)

        # LIDAR
        self.scan_sub = rospy.Subscriber('/lidar1/velodyne_points', PointCloud2, self.scanCallback)

        self.speed_sub  = rospy.Subscriber("/pacmod/as_tx/vehicle_speed", Float64, self.speed_callback)
        self.speed      = 0.0

        self.olat       = 40.0928563
        self.olon       = -88.2359994

        # read waypoints into the system 
        self.goal       = 0            
        self.read_waypoints() 

        self.desired_speed = 0.75  # m/s, reference speed
        self.max_accel     = 0.35 # % of acceleration
        self.pid_speed     = PID(1.2, 0.2, 0.6, wg=20)
        self.speed_filter  = OnlineFilter(1.2, 30, 4)
        self.ACCEL_LIMIT = {"fast": 0.35, "medium": 0.3, "slow": 0.0}

        # self.dest_point = axy.ll2xy(destinationWayPoint[1], destinationWayPoint[0], self.olat, self.olon)  # in (lon, lat)

        self.dest_point = destinationWayPoint[0], destinationWayPoint[1]
        # -------------------- PACMod setup --------------------

        self.gem_enable    = False
        self.pacmod_enable = False

        # GEM vehicle enable, publish once
        self.enable_pub = rospy.Publisher('/pacmod/as_rx/enable', Bool, queue_size=1)
        self.enable_cmd = Bool()
        self.enable_cmd.data = False

        # GEM vehicle gear control, neutral, forward and reverse, publish once
        self.gear_pub = rospy.Publisher('/pacmod/as_rx/shift_cmd', PacmodCmd, queue_size=1)
        self.gear_cmd = PacmodCmd()
        self.gear_cmd.ui16_cmd = 2 # SHIFT_NEUTRAL

        # GEM vehilce brake control
        self.brake_pub = rospy.Publisher('/pacmod/as_rx/brake_cmd', PacmodCmd, queue_size=1)
        self.brake_cmd = PacmodCmd()
        self.brake_cmd.enable = False
        self.brake_cmd.clear  = True
        self.brake_cmd.ignore = True

        # GEM vechile forward motion control
        self.accel_pub = rospy.Publisher('/pacmod/as_rx/accel_cmd', PacmodCmd, queue_size=1)
        self.accel_cmd = PacmodCmd()
        self.accel_cmd.enable = False
        self.accel_cmd.clear  = True
        self.accel_cmd.ignore = True

        # GEM vechile turn signal control
        self.turn_pub = rospy.Publisher('/pacmod/as_rx/turn_cmd', PacmodCmd, queue_size=1)
        self.turn_cmd = PacmodCmd()
        self.turn_cmd.ui16_cmd = 1 # None

        # GEM vechile steering wheel control
        self.steer_pub = rospy.Publisher('/pacmod/as_rx/steer_cmd', PositionWithSpeed, queue_size=1)
        self.steer_cmd = PositionWithSpeed()
        self.steer_cmd.angular_position = 0.0 # radians, -: clockwise, +: counter-clockwise
        self.steer_cmd.angular_velocity_limit = 2.0 # radians/second

    def scanCallback(self, msg):
        pc = pc2.read_points(msg, skip_nans=True, field_names=("x", "y", "z"))
        min_xyz = None
        min_phi = None  # angle between the point and the z-plane
        min_dist = math.inf
        for p in pc:  
            # type of p depends on your data type, first three entries are probably x,y,z
            # a list of 3D points forming the cloud.
            x, y, z = p[0], p[1], p[2]
            # cal the distances from car to obstacles and find the minimum
            dist = math.sqrt(x ** 2 + y ** 2 + z ** 2)
            # the point that belongs to the car itself should not be counted
            # also, only consider x, y, z > 0
            # Change: ignore points further than 10m
            if dist > 1 and dist < min_dist and dist < 10:
                # Calculate the angle between the projected point and the origin
                theta = math.atan2(y, x)
                if -1 / 4 * math.pi <= theta and theta <= 1 / 4 * math.pi:
                    min_dist = dist
                    min_xyz = (x, y, z)
                    min_phi = theta
                else:
                    min_phi = 0
        self.measure_distance = min_dist
        self.closest_point = min_xyz
        self.delta_angle = min_phi


    def inspva_callback(self, inspva_msg):
        self.lat     = inspva_msg.latitude  # latitude
        self.lon     = inspva_msg.longitude # longitude
        self.heading = inspva_msg.azimuth   # heading in degrees

    def speed_callback(self, msg):
        self.speed = round(msg.data, 3) # forward velocity in m/s

    def enable_callback(self, msg):
        self.pacmod_enable = msg.data

    def heading_to_yaw(self, heading_curr):
        # 0   <= heading < 90  --- 90 to 0     (pi/2 to 0)
        # 90  <= heading < 180 --- 0 to -90    (0 to -pi/2)
        # 180 <= heading < 270 --- -90 to -180 (-pi/2 to -pi)
        # 270 <= heading < 360 --- 180 to 90   (pi to pi/2)
        if (heading_curr >= 0 and heading_curr < 90):
            yaw_curr = np.radians(90 - heading_curr)
        elif(heading_curr >= 90 and heading_curr < 180):
            yaw_curr = np.radians(90 - heading_curr)
        elif(heading_curr >= 180 and heading_curr < 270):
            yaw_curr = np.radians(90 - heading_curr)
        else:
            yaw_curr = np.radians(450 - heading_curr)
        return yaw_curr

    def front2steer(self, f_angle):

        if(f_angle > 35):
            f_angle = 35

        if (f_angle < -35):
            f_angle = -35

        if (f_angle > 0):
            steer_angle = round(-0.1084*f_angle**2 + 21.775*f_angle, 2)

        elif (f_angle < 0):
            f_angle = -f_angle
            steer_angle = -round(-0.1084*f_angle**2 + 21.775*f_angle, 2)
        else:
            steer_angle = 0.0

        return steer_angle

    def read_waypoints(self):

        # x towards East and y towards North
        self.path_points_lon_x   = [float(destinationWayPoint[0])] # longitude
        self.path_points_lat_y   = [float(destinationWayPoint[1])] # latitude
        self.path_points_heading = [float(destinationWayPoint[2])] # heading
        self.wp_size             = len(self.path_points_lon_x)
        self.dist_arr            = np.zeros(self.wp_size)

    def wps_to_local_xy(self, lon_wp, lat_wp):
        # convert GNSS waypoints into local fixed frame reprented in x and y
        lon_wp_x, lat_wp_y = axy.ll2xy(lat_wp, lon_wp, self.olat, self.olon)
        return lon_wp_x, lat_wp_y   

    def get_gem_state(self):

        # vehicle gnss heading (yaw) in degrees
        # vehicle x, y position in fixed local frame, in meters
        # reference point is located at the center of GNSS antennas
        local_x_curr, local_y_curr = self.wps_to_local_xy(self.lon, self.lat)

        # heading to yaw (degrees to radians)
        # heading is calculated from two GNSS antennas
        curr_yaw = self.heading_to_yaw(self.heading) 

        # reference point is located at the center of rear axle
        curr_x = local_x_curr - self.offset * np.cos(curr_yaw)
        curr_y = local_y_curr - self.offset * np.sin(curr_yaw)

        return round(curr_x, 3), round(curr_y, 3), round(curr_yaw, 4)

    # find the angle bewtween two vectors    
    def find_angle(self, v1, v2):
        cosang = np.dot(v1, v2)
        crossang = np.cross(v1, v2)
        sinang = la.norm(np.cross(v1, v2))
        direction = 1 if crossang > 0 else -1
        # [-pi, pi]
        return direction * np.arctan2(sinang, cosang)

    # computes the Euclidean distance between two 2D points
    def dist(self, p1, p2):
        return round(np.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2), 3)


    def plot(self, plot_x_cur, plot_y_cur, plot_x_tar, plot_y_tar, text):
        # Read the CSV file into a pandas DataFrame
        # data = pd.read_csv(self.waypoint_filepath, header=None, names=['x', 'y', 'angle'])
        data_mp4 = pd.read_csv('log.csv', header=None, names=['x', 'y', 'angle'])

        # Create a scatter plot
        # plt.scatter(data['x'], data['y'], c=data['angle'], cmap='viridis')
        plt.scatter(data_mp4['x'], data_mp4['y'], c=data_mp4['angle'], cmap='viridis')

        # Add a scatter point
        plt.scatter(destinationWayPoint[0], destinationWayPoint[1], c='b', marker='x', s=100)
        plt.scatter(self.closest_point[0], self.closest_point[1], c='b', marker='o', s=100) 
        plt.scatter(plot_x_cur, plot_y_cur, c='r', marker='x', s=100)     # current position
        plt.scatter(plot_x_tar, plot_y_tar, c='r', marker='o', s=100)    # target position
        # plt.scatter(self.center1[0], self.center1[1], c='b', marker='o', s=200)    # target position
        # plt.scatter(self.center2[0], self.center2[1], c='b', marker='o', s=200)    # target position
        plt.colorbar()
        # plt.text(plot_x_cur, plot_y_cur, text, fontsize=14)

        # Set axis labels and title
        plt.xlabel('x')
        plt.ylabel('y')
        # plt.title('Angle values')

        # Show the plot
        plt.ion()

        # pause to avoid flicker
        plt.pause(0.001)
        # plt.show()
        plt.clf()


    def check_destination(self, cur_x, cur_y, threshold = 3):
        distance = self.dist(self.dest_point, (cur_x, cur_y))
        return distance <= threshold
    
    def check_obstacle(self):
        return self.measure_distance < 6
    
    def get_temp_goal(self, curr_x, curr_y, curr_yaw):
        goal = (destinationWayPoint[0], destinationWayPoint[1], destinationWayPoint[2])

        if self.check_obstacle():
            # generate new goal
            # car curr position curr_x, curr_y, curr_yaw
            # obstacle angle self.delta_angle, left+ right-
            # obstacle distance self.measure_distance
            
            # turn left or right
            if self.delta_angle <= 0: # if obstacle on the right
                turn_angle = - 90 - np.degrees(self.delta_angle) # turn left for (90-theta) and get negative
            else:
                turn_angle = 90 - np.degrees(self.delta_angle) # turn right for (90-theta)
            temp_heading = np.pi/2 - curr_yaw + np.radians(turn_angle)

            # set temp goal distance also be 5
            goal_dist = 5
            temp_x = curr_x + np.cos(np.pi/2 - temp_heading) * goal_dist
            temp_y = curr_y + np.sin(np.pi/2 - temp_heading) * goal_dist
            goal = (temp_x, temp_y, np.degrees(temp_heading))

        elif not self.check_destination(curr_x, curr_y):
            temp_goal_rate = 0.3
            temp_x = curr_x * (1-temp_goal_rate) + goal[0] * temp_goal_rate
            temp_y = curr_y * (1-temp_goal_rate) + goal[1] * temp_goal_rate
            # temp_heading =  
            goal = (temp_x, temp_y, goal[2])

        return goal
            
        
            

    def start_pp(self):
        stop_flag = False
        while not rospy.is_shutdown():

            if (self.gem_enable == False):

                if(self.pacmod_enable == True):

                    # ---------- enable PACMod ----------

                    # enable forward gear
                    self.gear_cmd.ui16_cmd = 3

                    # enable brake
                    self.brake_cmd.enable  = True
                    self.brake_cmd.clear   = False
                    self.brake_cmd.ignore  = False
                    self.brake_cmd.f64_cmd = 0.0

                    # enable gas 
                    self.accel_cmd.enable  = True
                    self.accel_cmd.clear   = False
                    self.accel_cmd.ignore  = False
                    self.accel_cmd.f64_cmd = 0.0

                    self.gear_pub.publish(self.gear_cmd)
                    print("Foward Engaged!")

                    self.turn_pub.publish(self.turn_cmd)
                    print("Turn Signal Ready!")
                    
                    self.brake_pub.publish(self.brake_cmd)
                    print("Brake Engaged!")

                    self.accel_pub.publish(self.accel_cmd)
                    print("Gas Engaged!")

                    self.gem_enable = True

            if stop_flag:
                if self.speed == 0:
                    print('STOPPPPPPPPPPP')
                    return
                print("[!BREAK!] near destination")
                self.brake_cmd.f64_cmd = 0.8
                self.brake_pub.publish(self.brake_cmd)
                self.accel_cmd.f64_cmd = 0.0
                self.accel_pub.publish(self.accel_cmd)
                self.rate.sleep()


            self.path_points_x = np.array(self.path_points_lon_x)
            self.path_points_y = np.array(self.path_points_lat_y)

            curr_x, curr_y, curr_yaw = self.get_gem_state()

            # check if the car get to destination
            if self.check_destination(curr_x, curr_y):
                stop_flag = True
                print("[!BREAK!] near destination")
                continue
            
            # # detect obstacle
            # if (self.check_obstacle()):
            #     # use /lidar1/velodyne_points to scan and find the shorest distance of obstacle, if the distance is less then 5, then obstacle occurs.
            #     if (self.steering_angle < 0):  # in radians
            #         # obs is on the right hand side, the car should turn left by 90 - angle of obs
            #         steering_angle_deg = 90 + np.degrees(self.steering_angle)
            #         self.turn_cmd.ui16_cmd = 2 # turn left
            #         self.accel_cmd.f64_cmd = 0.3
            #         self.steer_cmd.angular_position = np.radians(steering_angle_deg)
            #     elif (self.steering_angle > 0):
            #         # obs is on the left hand side, the car should turn right by 90 - angle of obs
            #         steering_angle_deg = np.degrees(self.steering_angle) - 90
            #         self.turn_cmd.ui16_cmd = 0 # turn right
            #         self.accel_cmd.f64_cmd = 0.3
            #         self.steer_cmd.angular_position = np.radians(steering_angle_deg)
            #     else:
            #         # obs in front of car, the car turn right by default
            #         steering_angle_deg = -30
            #         self.turn_cmd.ui16_cmd = 0 # turn right
            #         self.accel_cmd.f64_cmd = 0.3
            #         self.steer_cmd.angular_position = np.radians(steering_angle_deg)
            #     self.accel_pub.publish(self.accel_cmd)
            #     self.steer_pub.publish(self.steer_cmd)
            #     self.turn_pub.publish(self.turn_cmd)
            #     continue

            temp_goal = self.get_temp_goal(curr_x, curr_y, curr_yaw)

            # find the curvature and the angle 
            # version 1
            # alpha_v1 = self.heading_to_yaw(temp_goal[2]) - curr_yaw

            # version 2
            v1 = [temp_goal[0]-curr_x ,temp_goal[1]-curr_y]
            v2 = [np.cos(curr_yaw), np.sin(curr_yaw)]
            alpha_v2 = self.find_angle(v2,v1)

            # version 3
            # alpha_v3 = math.atan(v1[1]/v1[0]) - curr_yaw 

            # alpha = alpha_v3 
            # alpha = (alpha_v3 + alpha_v1) / 2 # combine two values? 
            alpha = alpha_v2

            # plot the current position and the target position
            plot_x_cur, plot_y_cur = curr_x, curr_y
            plot_x_tar, plot_y_tar = temp_goal[0], temp_goal[1]
            # text = f"v1:{v1[0]:.2f},{v1[1]:.2f}\nv2:{v2[0]:.2f},{v2[1]:2f}\nalpha:{alpha:.2f}"
            toD = lambda theta: theta * 180 / np.pi
            text = f"v1:({v1[0]:.2f},{v1[1]:.2f})\ncurr_yaw:{toD(curr_yaw):.2f}\ntar_heading:{temp_goal[2]}\nalpha:{toD(alpha):.2f}"
            
            self.plot(plot_x_cur, plot_y_cur, plot_x_tar, plot_y_tar, text)




            # ----------------- tuning this part as needed -----------------
            L = self.dist((curr_x, curr_y), (temp_goal[0], temp_goal[1]))
            k       = 0.41 
            angle_i = math.atan((k * 2 * self.wheelbase * math.sin(alpha)) / L) 
            angle   = angle_i*2
            # ----------------- tuning this part as needed -----------------

            f_delta = round(np.clip(angle, -0.61, 0.61), 3)

            f_delta_deg = np.degrees(f_delta)

            # steering_angle in degrees
            steering_angle = self.front2steer(f_delta_deg)



            if(self.gem_enable == True):
                # print("Current index: " + str(self.goal))
                print("Forward velocity: " + str(self.speed))
                ct_error = round(np.sin(alpha) * L, 3)
                print("Crosstrack Error: " + str(ct_error))
                print("Front steering angle: " + str(np.degrees(f_delta)) + " degrees")
                print("Steering wheel angle: " + str(steering_angle) + " degrees" )

                print(f"curr_x: {curr_x}, curr_y: {curr_y},  curr_yaw: {curr_yaw}")
                print(f"delta_angle: {self.delta_angle}")
                print(f"tar_x: {temp_goal[0]}, tar_y: {temp_goal[1]}, tar_head: {temp_goal[2]}")
                print(f"destination point: {self.dest_point}")
                print("\n")

            # if (self.goal >= 625 and self.goal <= 940):
            #     self.desired_speed = 1.5
            # else:
            #     self.desired_speed = 0.7

            current_time = rospy.get_time()
            filt_vel     = self.speed_filter.get_data(self.speed)
            output_accel = self.pid_speed.get_control(current_time, self.desired_speed - filt_vel)

            if filt_vel <= 0.1:
                self.max_accel = self.ACCEL_LIMIT["fast"]
            elif filt_vel >= self.desired_speed:
                self.max_accel = self.ACCEL_LIMIT["slow"]
            else:
                self.max_accel = self.ACCEL_LIMIT["medium"]


            if output_accel > self.max_accel:
                output_accel = self.max_accel

            if output_accel < 0.2:
                output_accel = 0.2

            if (f_delta_deg <= 30 and f_delta_deg >= -30):
                self.turn_cmd.ui16_cmd = 1
            elif(f_delta_deg > 30):
                self.turn_cmd.ui16_cmd = 2 # turn left
            else:
                self.turn_cmd.ui16_cmd = 0 # turn right


            

            self.accel_cmd.f64_cmd = output_accel
            self.steer_cmd.angular_position = np.radians(steering_angle)
            self.accel_pub.publish(self.accel_cmd)
            self.steer_pub.publish(self.steer_cmd)
            self.turn_pub.publish(self.turn_cmd)

            self.rate.sleep()


def pure_pursuit():

    rospy.init_node('gnss_pp_node', anonymous=True)
    pp = PurePursuit()

    try:
        pp.start_pp()
    except rospy.ROSInterruptException:
        pass


if __name__ == '__main__':
    pure_pursuit()
