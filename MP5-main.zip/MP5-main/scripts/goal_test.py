import matplotlib.pyplot as plt
import csv
import os
import numpy as np

def dist(p1, p2):
    return round(np.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2), 3)

def angle_diff(angle1, angle2):
    return (angle1 - angle2 + 360) % 360

def heading_to_yaw(heading_curr):
    # 0   <= heading < 90  --- 90 to 0     (pi/2 to 0)
    # 90  <= heading < 180 --- 0 to -90    (0 to -pi/2)
    # 180 <= heading < 270 --- -90 to -180 (-pi/2 to -pi)
    # 270 <= heading < 360 --- 180 to 90   (pi to pi/2)
    if (heading_curr >= 0 and heading_curr < 90):
        yaw_curr = np.radians(90 - heading_curr)
    elif(heading_curr >= 90 and heading_curr < 180):
        yaw_curr = np.radians(90 - heading_curr)
    elif(heading_curr >= 180 and heading_curr < 270):
        yaw_curr = np.radians(90 - heading_curr)
    else:
        yaw_curr = np.radians(450 - heading_curr)
    return yaw_curr

dirname  = os.path.dirname(__file__)
filename = os.path.join(dirname, "../waypoints/new.csv")

with open(filename) as f:
    path_points = [tuple(line) for line in csv.reader(f)]

path_points_lon_x   = [float(point[0]) for point in path_points] # longitude
path_points_lat_y   = [float(point[1]) for point in path_points] # latitude
path_points_heading = [float(point[2]) for point in path_points]

path_points_x = np.array(path_points_lon_x)
path_points_y = np.array(path_points_lat_y)

# Define the point coordinates (cur_x, cur_y)
cur_x, cur_y, cur_yaw = 21.47055452366399,-5.797238848685334,98.98974847076886

# cur_x, cur_y, cur_yaw = 54.77,-0.145,86.008
# 0.  distance check
dist_arr = np.array([dist((path_points_x[i], path_points_y[i]), (cur_x, cur_y)) for i in range(len(path_points_x))])

look_ahead = 2
# finding those points which are less than the look ahead distance (will be behind and ahead of the vehicle)
search_radius = 0.3
goal_arr = np.where((dist_arr < look_ahead + search_radius) & (dist_arr > look_ahead - search_radius))[0]


#
# print(angle_diff(180, 10))
#
def find_angle(v1, v2):
    cosang = np.dot(v1, v2)
    sinang = np.linalg.norm(np.cross(v1, v2))
    # [-pi, pi]
    return np.arctan2(sinang, cosang)

filtered_goal_arr = []
for i in goal_arr:
    # print(cur_yaw)
    # Calculate angle from current point to goal point
    # angle_to_goal = (-np.degrees(np.arctan2(cur_y - path_points_y[i], cur_x - path_points_x[i])) + 450)%360
    v1 = (path_points_x[i] - cur_x, path_points_y[i] - cur_y)
    yaw =  heading_to_yaw(cur_yaw)
    v2 = (np.cos(yaw), np.sin(yaw))
    angle_to_goal = find_angle(v1,v2)
    # angle_to_goal = (angle_to_goal + 360) % 360
    # print(angle_to_goal)
    # Calculate angle differences
    # angle_diff_cur_yaw_goal = abs(angle_diff(angle_to_goal, cur_yaw))
    # print(angle_diff_cur_yaw_goal)
    # angle_diff_cur_yaw_heading = abs(angle_diff(cur_yaw, path_points_heading[i]))

    if abs(angle_to_goal) < np.pi/2:
        # print(angle_to_goal)
        filtered_goal_arr.append(i)

goal = -1
# another goal_finding method
# find the last goal in the following degree difference
degrees = [np.pi/36, np.pi/24, np.pi/12, np.pi/9, np.pi/6, np.pi/3, np.pi/2]
goal_candidates = [None] * 7

# finding the goal point which is the smallest angle with current yaw
for idx in filtered_goal_arr:
    # diff_angle = np.radians(abs(path_points_heading[idx]-cur_yaw))
    yaw_goal = heading_to_yaw(path_points_heading[idx])
    v1 = (np.cos(yaw_goal), np.sin(yaw_goal))
    yaw = heading_to_yaw(cur_yaw)
    v2 = (np.cos(yaw), np.sin(yaw))
    angle_to_goal = find_angle(v1, v2)
    diff_angle = angle_to_goal
    # diff_angle = abs(heading_to_yaw(path_points_heading[idx]) - heading_to_yaw(cur_yaw))


    # find correct look-ahead point by using heading information
    for i, d in enumerate(degrees):
        if diff_angle < d:
            goal_candidates[i] = idx
            break

for idx in goal_candidates:
    if idx is not None:
        print("!")
        goal = idx
        break

v1 = [cur_x - path_points_x[goal] , cur_y - path_points_y[goal]]
yaw =  heading_to_yaw(cur_yaw)
v2 = (np.cos(yaw), np.sin(yaw))
alpha_v2 = find_angle(v1,v2)

print(np.degrees(np.pi-alpha_v2))


# Create a figure and axis
fig, ax = plt.subplots(figsize=(8, 8))

# Plot the data on the axis
ax.plot(path_points_lon_x, path_points_lat_y, label='Line plot')

# Set labels for the x and y axes
ax.set_xlabel('X-axis')
ax.set_ylabel('Y-axis')

# Set a title for the plot
ax.set_title('Simple Line Plot Example')

# Plot the point on the axis
ax.scatter(cur_x, cur_y, c='red', marker='o', label='Point (cur_x, cur_y)')

# Plot goal_arr points on the axis
goal_points_x = [path_points_x[i] for i in filtered_goal_arr]
goal_points_y = [path_points_y[i] for i in filtered_goal_arr]
ax.scatter(goal_points_x, goal_points_y, c='green', marker='x', label='Goal Points')

# Draw the cur_yaw arrow
arrow_length = 0.5
ax.quiver(cur_x, cur_y, arrow_length * np.sin(np.radians(cur_yaw)), arrow_length * np.cos(np.radians(cur_yaw)), color='red', angles='xy', scale_units='xy', scale=1, label='cur_yaw')
ax.quiver(cur_x, cur_y, arrow_length * np.sin(np.radians(cur_yaw-np.degrees(np.pi-alpha_v2))), arrow_length * np.cos(np.radians(cur_yaw-np.degrees(np.pi-alpha_v2))), color='orange', angles='xy', scale_units='xy', scale=1, label='cur_yaw')

# Draw arrows for only 20 evenly spaced points in the original path
num_arrows = 20
indices = np.linspace(0, len(path_points_lon_x) - 1, num_arrows, dtype=int)
for i in indices:
    x, y, heading = path_points_lon_x[i], path_points_lat_y[i], path_points_heading[i]
    dx = arrow_length * np.sin(np.radians(heading))
    dy = arrow_length * np.cos(np.radians(heading))
    ax.arrow(x, y, dx, dy, head_width=0.1, head_length=0.15, fc='blue', ec='blue')

# Draw the goal points' heading arrows
for i, goal_point_x, goal_point_y in zip(filtered_goal_arr, goal_points_x, goal_points_y):
    ax.quiver(goal_point_x, goal_point_y, arrow_length * np.sin(np.radians(path_points_heading[i])), arrow_length * np.cos(np.radians(path_points_heading[i])), color='green', angles='xy', scale_units='xy', scale=1)

# Draw two circles
circle_inner = plt.Circle((cur_x, cur_y), look_ahead - search_radius, color='blue', fill=False, label='Inner Circle')
circle_outer = plt.Circle((cur_x, cur_y), look_ahead + search_radius, color='blue', fill=False, label='Outer Circle')
ax.add_artist(circle_inner)
ax.add_artist(circle_outer)

# Plot the point on the axis
ax.scatter(path_points_x[goal], path_points_y[goal], c='red', marker='x', label='Point (cur_x, cur_y)')


# Set the aspect ratio to be equal
ax.set_aspect('equal', adjustable='box')

# Display the legend
ax.legend(loc='upper right', bbox_to_anchor=(1.5, 1))

# Show the plot
plt.show()
