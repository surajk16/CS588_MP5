from __future__ import print_function

# ROS Headers
import rospy
from lidar_scan import block_scan
from gem_gnss_pp_tracker_pid import pure_pursuit

import configparser
import os 
import sys


if __name__ == '__main__':
    abs_filename, abs_center1, abs_center2 = None, None, None 
    rospy.init_node('mp5_node', anonymous=True)
    if len(sys.argv) == 1:
        abs_filename, abs_center1, abs_center2 = block_scan()
    else:
        # create a new configuration object
        config = configparser.ConfigParser()
        dirname = os.path.dirname(__file__)
        config_filename = sys.argv[1]
        # read the configuration from a file
        config.read(os.path.join(dirname, config_filename))
        abs_center1, abs_center2, abs_filename = config["absolute_center"]["center1"], config["absolute_center"]["center2"], config["absolute_filename"]["filename"]
        abs_center1 = eval(abs_center1)
        abs_center2 = eval(abs_center2)
        print(abs_center1, abs_center2)

    pure_pursuit(abs_center1, abs_center2, abs_filename)