import numpy as np
import numpy.linalg as la

curr_x= 15.793
curr_y= -4.962
curr_yaw= -0.593
tar_x= 13.896429385642525
tar_y= -5.448012050356338

# v1 = np.array([tar_x - curr_x, tar_y - curr_y])
v1 = np.array((1,0))
v2 = np.array((-0.5,-1))
def cal(v1, v2):
    cosang = np.dot(v1, v2)
    crossang = np.cross(v1, v2)
    sinang = la.norm(crossang)
    d = -1 if crossang <0 else 1
    return d*np.arctan2(sinang, cosang)
# [-pi, pi]
print(cal(v1, v2))