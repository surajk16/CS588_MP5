#!/usr/bin/env python3

#================================================================
# File name: waypoints.py                                                                  
# Description: Generate waypoints in the relative coordinate system that centers at the car                                                    
# Author: Group 3                                                                    
# Version: 0.1                                                                    
# Usage: rosrun gem_gnss waypoints.py                                                                      
# Python version: 3.8                                                             
#================================================================
from __future__ import print_function

# Python Headers
import math
import matplotlib.pyplot as plt
import numpy as np



class WaypointGenerator():
    """Generate waypoints within two centers and the car's current position"""
    def __init__(self, center1, center2, current_position=(0,0), current_heading=0):
        self.center1 = center1
        self.center2 = center2
        self.current_position = current_position
        self.current_heading = current_heading
        self.waypoints = []

    def saveAsCSV(self, filename):
        with open(filename, 'w') as f:
            for x, y, heading in self.waypoints:
                heading = (heading + 360) % 360
                f.write("{},{},{}\n".format(x, y, heading))

    def readFromCSV(self, filename):
        waypoints = []
        with open(filename, 'r') as f:
            for line in f.readlines():
                x, y, heading = map(lambda k: float(k), line.strip().split(","))
                waypoints.append((x, y, heading))
        self.waypoints = waypoints

    # computes the Euclidean distance between two 2D points
    def dist(self, p1, p2):
        return round(math.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2), 3)

    def get_tangent_point(self, center, radius, current_pos):
        # Calculate the distance between the current position and the center of the circle
        hypotenuse = self.dist(center, current_pos)

        # Calculate the angle between the line connecting the current position and the center of the circle
        # and the positive x-axis
        angle = math.atan2(center[1] - current_pos[1], center[0] - current_pos[0])

        # Calculate the angle between the line connecting the current position and the center of the circle
        # and the tangent line at the tangent point
        print(radius/hypotenuse)
        
        theta = math.asin(radius / hypotenuse) if radius/hypotenuse <= 1 else 1.57

        # Calculate the coordinates of the tangent point using the current point and hypotenuse
        x1 = current_pos[0] + hypotenuse * math.cos(angle + theta)
        y1 = current_pos[1] + hypotenuse * math.sin(angle + theta)
        x2 = current_pos[0] + hypotenuse * math.cos(angle - theta)
        y2 = current_pos[1] + hypotenuse * math.sin(angle - theta)

        # TODO: which point to choose
        tangent_point = None 
        if abs(angle + theta - self.current_heading) < abs(angle - theta - self.current_heading):
            tangent_point = (x1, y1)
        else:
            tangent_point = (x2, y2)

        return tangent_point
    
    def get_points_on_circle(self, start_point, center, radius, num_points=200):
        """Returns a list of points on the circle"""
        # Calculate the angle between each point
        delta_theta = 2 * math.pi / num_points
        start_theta = math.atan2(start_point[1] - center[1], start_point[0] - center[0])

        # determine clockwise or counterclockwise
        x1 = center[0] + radius * math.cos(start_theta+delta_theta)
        direction = 1 if x1 > start_point[0] else -1

        # Generate the points on the circle
        points = []
        for i in range(num_points):
            theta = start_theta + i * delta_theta
            x = center[0] + radius * math.cos(theta)
            y = center[1] + radius * math.sin(theta)
            points.append((round(x,3), round(y,3), round((theta + direction * math.pi/2)/math.pi*180,3)))

        return points
    
    def get_points_between_two_points(self, point1, point2, num_points=50):
        # Calculate the distance between the two points
        dx = point2[0] - point1[0]
        dy = point2[1] - point1[1]
        dist = math.sqrt(dx**2 + dy**2)

        # direction from point1 to point2
        angle = math.atan2(dy, dx) / math.pi * 180

        # Calculate the step size between each point
        step_size = dist / (num_points - 1)

        # Generate the points between the two points
        points = []
        for i in range(num_points):
            x = point1[0] + i * step_size * dx / dist
            y = point1[1] + i * step_size * dy / dist
            points.append((round(x,3), round(y,3), angle)) 

        return points
    

    def get_points_on_arc(self, point1, point2, center, radius, num_points):
        # Calculate the angles of the two points
        angle1 = math.atan2(point1[1] - center[1], point1[0] - center[0])
        angle2 = math.atan2(point2[1] - center[1], point2[0] - center[0])

        # Calculate the angle between the two points
        if angle1 < angle2:
            angle = angle2 - angle1
        else:
            angle = angle2 + 2 * math.pi - angle1

        # Calculate the step size between each point
        step_size = angle / (num_points - 1)

        # Generate the points on the arc
        points = []
        for i in range(num_points):
            theta = angle1 + i * step_size
            x = center[0] + radius * math.cos(theta)
            y = center[1] + radius * math.sin(theta)
            points.append((x, y))

        return points

    def generateWaypoints(self):
        """Generate waypoints within two centers and the car's current position"""
        center1, center2, current_pos = self.center1, self.center2, self.current_position
        # TODO: choose the closer one to be the center of the circle? 
        if self.dist(center1, current_pos) > self.dist(center2, current_pos):
            center1, center2 = center2, center1
        # get the midpoint of two centers as the final destination
        dst = ((center1[0]+center2[0])/2, (center1[1]+center2[1])/2)
        # calculate the radius
        radius = self.dist(center1, center2)/2
        print(radius)
        # get the tangent point 
        tangent_point = self.get_tangent_point(center1, radius, current_pos)
        print(tangent_point)
        # generate waypoints
        seg1 = self.get_points_between_two_points(current_pos, tangent_point)
        seg2 = self.get_points_on_circle(tangent_point, center1, radius)
        self.waypoints = seg1 + seg2
        return seg1 + seg2


    def get_centers(self):
        return self.center1, self.center2
    
    def transform_points(self, dx, dy, dtheta):
        """Use GPS info to transform current state
            dx: lon
            dy: lat
            dtheta: heading
        """
        # step 1: rotate 
        v1 = np.array([np.sin(dtheta/180*np.pi), np.cos(dtheta/180*np.pi)])
        v2 = np.array([1, 0])

        cos_theta = np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2))
        theta = np.arccos(cos_theta)
        if 270 > dtheta > 90:
            theta *= -1

        rot_mat = np.array([[np.cos(theta), -np.sin(theta)],
                            [np.sin(theta), np.cos(theta)]])
        
        def trans(p):
            p1 = np.array(p)
            p2 = np.dot(rot_mat, p1 / np.linalg.norm(v1) * np.linalg.norm(v2))
            return (p2[0], p2[1])

        self.center1 = trans(self.center1)
        self.center2 = trans(self.center2)
        self.current_position = trans(self.current_position)

        # step 2: transform with dx dy
        self.current_position = (self.current_position[0]+dx, self.current_position[1]+dy)
        self.center1 = (self.center1[0]+dx, self.center1[1]+dy)
        self.center2 = (self.center2[0]+dx, self.center2[1]+dy)


        self.current_heading = - self.current_heading + dtheta
        waypoints = []
        for w in self.waypoints:
            x, y = trans((w[0],w[1]))
            waypoints.append((x+dx, y+dy, -w[2]+dtheta))
        self.waypoints = waypoints

    def visualize(self, block=True, c="lidar"):
        data = self.waypoints
        x = np.array([d[0] for d in data])
        y = np.array([d[1] for d in data])
        direction = np.array([d[2] for d in data]) if c=="lidar" else np.array([-d[2]+90 for d in data]) 

        # Create a scatter plot with arrows indicating direction
        fig, ax = plt.subplots()
        ax.scatter(x, y, color='red')
        ax.quiver(x, y, np.cos(np.radians(direction)), np.sin(np.radians(direction)),
                scale=10, color='blue', alpha=0.5)
        
        ax.scatter(*zip(self.center1, self.center2), color='green', marker='x', s=100, label='Block Centers')

        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_title('Directional Scatter Plot')
        plt.show(block=block)

if __name__ == "__main__":
    center1, center2 = (2, 2), (2, -2)
    lat, lon, heading = 10, 20, 180
    wpg = WaypointGenerator(center1, center2)
    wpg.generateWaypoints()
    # wpg.readFromCSV("waypoints/relative_waypoints_1409.csv")
    wpg.visualize(False)
    wpg.transform_points(lon,lat,heading)
    wpg.visualize(c="gps")
    # wpg.saveAsCSV("waypoints/relative_waypoints.csv")
