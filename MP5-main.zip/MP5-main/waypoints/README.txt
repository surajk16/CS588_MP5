lat: 40.0928563         perpendicular to building
lon: -88.2359994        along with building
heading: 90
