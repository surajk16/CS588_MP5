import numpy as np
import matplotlib.pyplot as plt





def test(data):
    # Parse the data and filter out points too far
    # threshold = 6
    points = np.array(data)
    # filtered_points = points[np.linalg.norm(points, axis=1) <= threshold]

    # Project points to the XY plane
    # projected_points = points[:, :2]
    projected_points = points

    # Split the plane into blocks
    num_blocks = (12, 12)  # 5x5 blocks
    block_ranges = [
        (np.min(projected_points[:, 0]), np.max(projected_points[:, 0])),
        (np.min(projected_points[:, 1]), np.max(projected_points[:, 1]))
    ]
    block_size = [
        (block_ranges[0][1] - block_ranges[0][0]) / num_blocks[0],
        (block_ranges[1][1] - block_ranges[1][0]) / num_blocks[1]
    ]

    # Calculate the amount of points in each block
    block_counts = np.zeros(num_blocks, dtype=int)
    for point in projected_points:
        if point[2] > 0 or point[2] < -1.4:
            continue
        block_idx = (
            int((point[0] - block_ranges[0][0]) // block_size[0]),
            int((point[1] - block_ranges[1][0]) // block_size[1])
        )
        if block_idx[0] >= num_blocks[0] or block_idx[1] >= num_blocks[1]:
            continue
        block_counts[block_idx] += 1

    # Find the central point of the two blocks with most points
    two_highest_blocks = np.argpartition(block_counts.flatten(), -2)[-2:]
    block_centers = []
    for block_idx in two_highest_blocks:
        x_idx, y_idx = np.unravel_index(block_idx, block_counts.shape)
        x_center = block_ranges[0][0] + (x_idx + 0.5) * block_size[0]
        y_center = block_ranges[1][0] + (y_idx + 0.5) * block_size[1]
        block_centers.append((x_center, y_center))

    print(block_centers)


    # Visualize the projected points and block centers
    plt.scatter(projected_points[:, 0], projected_points[:, 1], label='Projected Points')
    plt.scatter(*zip(*block_centers), color='red', marker='x', s=100, label='Block Centers')

    # Set up the gridlines for the blocks
    for i in range(1, num_blocks[0]):
        plt.axvline(block_ranges[0][0] + i * block_size[0], color='grey', linestyle='--', linewidth=0.5)
    for i in range(1, num_blocks[1]):
        plt.axhline(block_ranges[1][0] + i * block_size[1], color='grey', linestyle='--', linewidth=0.5)

    plt.legend()
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.title('Projected Points and Block Centers')
    plt.show()

def get_dense_centers(points, num_centers):
    # Determine grid size
    grid_size = 1
    
    # Create grid
    min_x, min_y = np.min(points, axis=0)
    max_x, max_y = np.max(points, axis=0)
    num_cols = int(np.ceil((max_x - min_x) / grid_size))
    num_rows = int(np.ceil((max_y - min_y) / grid_size))
    grid = np.zeros((num_rows, num_cols))
    
    # Count points in each grid cell
    row_idxs = np.floor((points[:,1] - min_y) / grid_size).astype(int)
    col_idxs = np.floor((points[:,0] - min_x) / grid_size).astype(int)
    for row, col in zip(row_idxs, col_idxs):
        grid[row, col] += 1
    
    # Compute center of each dense grid cell
    centers = []
    for row in range(num_rows):
        for col in range(num_cols):
            if grid[row, col] > 0:
                center_x = min_x + (col + 0.5) * grid_size
                center_y = min_y + (row + 0.5) * grid_size
                centers.append([center_x, center_y])
    centers = np.array(centers)
    
    # Compute density of each center
    densities = np.zeros(len(centers))
    for i, center in enumerate(centers):
        dists = np.sqrt(np.sum((points - center)**2, axis=1))
        densities[i] = np.sum(dists <= grid_size)
    
    # Get the num_centers densest centers
    densest_idxs = np.argsort(densities)[::-1][:num_centers]
    densest_centers = centers[densest_idxs]
    
    return densest_centers


if __name__ == '__main__':
    # points = []
    # for i in range(1,6):
    #   with open(f"point_cloud_{i}.txt") as f:
    #       for line in f:
    #           x, y, z = map(lambda k: float(k), line.split(","))
    #           if 1 < np.sqrt(x**2 + y**2 + z**2) < 8:
    #               points.append([x, y, z])

    #   print(test(points))
    points = []
    with open(f"point_cloud/point_cloud_0426.txt") as f:
        for line in f:
            x, y, z = map(lambda k: float(k), line.split(","))
            if 1 < np.sqrt(x**2 + y**2 + z**2) < 10:
                points.append([x, y, z])

    print(test(points))

    